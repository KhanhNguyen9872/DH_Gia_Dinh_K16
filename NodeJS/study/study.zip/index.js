//index.js
const { generateRandomNumber, celcius2Fah } = require('./utils');

console.log(`Random Number: ${generateRandomNumber()}`);
console.log(`Celcius to Fahrenheit: ${celcius2Fah(0)}`);