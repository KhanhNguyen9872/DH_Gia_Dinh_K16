﻿namespace QLThuVien_Buoi9
{
}

namespace QLThuVien_Buoi9
{


    public partial class DataSetBai3
    {
        partial class DSSachDataTable
        {
        }
    }
}
