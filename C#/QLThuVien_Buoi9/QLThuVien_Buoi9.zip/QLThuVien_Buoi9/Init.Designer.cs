﻿namespace QLThuVien_Buoi9
{
    partial class Init
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabBai1 = new System.Windows.Forms.TabPage();
            this.tabBai2 = new System.Windows.Forms.TabPage();
            this.tabBai3 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabBai1);
            this.tabControl1.Controls.Add(this.tabBai2);
            this.tabControl1.Controls.Add(this.tabBai3);
            this.tabControl1.Location = new System.Drawing.Point(0, 1);
            this.tabControl1.MaximumSize = new System.Drawing.Size(747, 355);
            this.tabControl1.MinimumSize = new System.Drawing.Size(747, 355);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(747, 355);
            this.tabControl1.TabIndex = 0;
            // 
            // tabBai1
            // 
            this.tabBai1.Location = new System.Drawing.Point(4, 22);
            this.tabBai1.Name = "tabBai1";
            this.tabBai1.Padding = new System.Windows.Forms.Padding(3);
            this.tabBai1.Size = new System.Drawing.Size(739, 329);
            this.tabBai1.TabIndex = 0;
            this.tabBai1.Text = "Thông tin độc giả";
            this.tabBai1.UseVisualStyleBackColor = true;
            // 
            // tabBai2
            // 
            this.tabBai2.Location = new System.Drawing.Point(4, 22);
            this.tabBai2.Name = "tabBai2";
            this.tabBai2.Padding = new System.Windows.Forms.Padding(3);
            this.tabBai2.Size = new System.Drawing.Size(739, 329);
            this.tabBai2.TabIndex = 1;
            this.tabBai2.Text = "Thông tin sách";
            this.tabBai2.UseVisualStyleBackColor = true;
            // 
            // tabBai3
            // 
            this.tabBai3.Location = new System.Drawing.Point(4, 22);
            this.tabBai3.Name = "tabBai3";
            this.tabBai3.Padding = new System.Windows.Forms.Padding(3);
            this.tabBai3.Size = new System.Drawing.Size(739, 329);
            this.tabBai3.TabIndex = 2;
            this.tabBai3.Text = "Thông tin độc giả mượn sách";
            this.tabBai3.UseVisualStyleBackColor = true;
            // 
            // Init
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 354);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Init";
            this.ShowIcon = false;
            this.Text = "QLThuVien | Buoi 9 | Nhom 1";
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabBai1;
        private System.Windows.Forms.TabPage tabBai2;
        private System.Windows.Forms.TabPage tabBai3;
    }
}

