public interface InBoundary {
    public void execute(RequestData requestData) throws Exception;
}
