public interface OutBoundary {
    public void output(ResponseData responseData) throws Exception;
}
