Nhóm 6 - 221402
- Nguyễn Văn Khánh (Nhóm trưởng)
- Lê Lâm Chiến Thắng
- Trương Ngọc Hào
- Vũ Đức Thịnh